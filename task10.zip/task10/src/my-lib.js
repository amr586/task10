"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.log = log;
function log(message) {
    console.log("LOG:", message);
}
//# sourceMappingURL=my-lib.js.map