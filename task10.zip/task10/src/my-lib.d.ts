export {};
//# sourceMappingURL=my-lib.d.ts.map